Novel Composition Test Functions for Numerical Global Optimization

func_test.m is the main program, a basic PSO algorithm PSO_func.m is attached.

SIS_novel_func.m is the function program,including six composition functions
f=SIS_novel_func(x,func_num)
func_num: from 1 to 6
Now it's just for 10D
The mat files are the associate data files used in the SIS_novel_func.

Using func_plot.m, you could get the 2-D landscape maps for the six functions.






reference: 
J. J. Liang, P. N. Suganthan and K. Deb, "Novel Composition Test Functions for Numerical 
Global Optimization", IEEE Swarm Intelligence Symposium, pp. 68-75, June 2005.
